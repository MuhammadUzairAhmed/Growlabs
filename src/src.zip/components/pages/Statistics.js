import React, { Component } from 'react';

class Statistics extends Component {
  render(){
    return (
      <div>
        <h1>Statisitics</h1>

        <h2>Get Started</h2>
        <ol>
          <li>Review the demo app</li>
          <li>Remove the demo and start coding: npm run remove-demo</li>
        </ol>
      </div>
    );  
  };  
};

export default Statistics;
