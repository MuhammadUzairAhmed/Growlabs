export default {
    fuelSavings: {
        NOTIFICATIONS : [],
        BACKLOG : [],
        BACKLOGCURRENTSTATE: [],
        BACKLOGWIDGET: [
           { items:[],boolen:'' }
        ],
        FINANCIAL: [],
        FILES : [],
        CHAT : [],
        CHART : [],
        ACTIVEWIDGET: [],
        USER_DETAILS : [],
        MILESTONE : [],
        IS_LOADING : false,
        chartValues:{}
    }
};
